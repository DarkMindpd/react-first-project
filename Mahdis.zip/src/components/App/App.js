import { useEffect, useReducer, useState } from "react";
import { Button } from "flowbite-react";
import { BrowserRouter, Route, Router, Routes } from "react-router-dom";
import Menu from "./Menu/Menu";
import Footer from "./Footer/Footer";
import Landing from "./Landing/Landing";
import Shop from "./Shop/Shop";
import Fashions from "./Fashions/Fashions";

const App = () => {
  return (
    <>
      <div className="bg-white max-w-screen-xl mx-auto min-h-screen flex justify-between flex-col">
        <BrowserRouter>
          <Menu />
          <main className="my-8">
            <div className="container mx-auto px-6">
              <Routes>
                <Route path="/" element={<Landing />} />
                <Route path="/Shop" element={<Shop />} />
                <Route path="/Fashions" element={<Fashions />} />
              </Routes>
            </div>
          </main>
          <Footer />
        </BrowserRouter>
      </div>
    </>
  );
};

export default App;
